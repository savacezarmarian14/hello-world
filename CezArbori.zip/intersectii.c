#include "intersectii.h"




/// SA MOARA MAMA DACA NU J=0 A FOST CEA MAI GREA CCHESTIE DIN TEMA ASTA SA MOR randul148



///ArboreDeIntervale *arbore = construieste_arbore(0, 11, 0, actualizare_cu_delta, suma_raspunsurilor);
// functie ajutatoare
void afiseaza_lista_intervale(ListaIntervale2D *lista) {
    int i;
    for (i = 0; i < lista->dimensiune; i++) {
        Interval2D *interv = lista->intervale[i];
        printf("{punct stanga x: %d, punct stanga y: %d, punct dreapta x: %d, punct dreapta y: %d}\n",
                    interv->punct_stanga->x, interv->punct_stanga->y,
                    interv->punct_dreapta->x, interv->punct_dreapta->y);
    }
}


ListaIntervale2D* citeste_intrare(char *nume_fisier_intrare) {
    FILE *date_intrare =fopen(nume_fisier_intrare,"r");
    ListaIntervale2D *lista=(ListaIntervale2D*)malloc(sizeof(ListaIntervale2D));
    fscanf(date_intrare,"%d",&lista->dimensiune);
    lista->intervale=(Interval2D**)malloc(lista->dimensiune*sizeof(Interval2D*));
    for (int i = 0; i < lista->dimensiune; ++i)
    {
        lista->intervale[i]=(Interval2D*)malloc(sizeof(Interval2D));
        lista->intervale[i]->punct_stanga=(Punct2D*)malloc(sizeof(Punct2D));
        lista->intervale[i]->punct_dreapta=(Punct2D*)malloc(sizeof(Punct2D));
        fscanf(date_intrare,"%d %d %d %d",&(lista->intervale[i]->punct_stanga->x),
            &(lista->intervale[i]->punct_stanga->y),
            &(lista->intervale[i]->punct_dreapta->x),
            &(lista->intervale[i]->punct_dreapta->y));
    }
    return lista;
}

// ! Functie pentru actualizarea in arbore
// ! O veti da ca parametru cand initializati arborele
void actualizare_cu_delta(Nod *nod, int v2) {
    nod->info += v2;
}

// ! Functie pentru combinarea raspunsurilor in arbore
// ! O veti da ca parametru cand initializati arborele
int suma_raspunsurilor(int r1, int r2) {
    return r1 + r2;
}

int cauta_ymax(ListaIntervale2D *lista){
    int ymax=-1;
    for (int i = 0; i < lista->dimensiune; ++i)
    {
        if(lista->intervale[i]->punct_dreapta->y > ymax)
            ymax = lista->intervale[i]->punct_dreapta->y; 
    }
    return ymax;
}
int cauta_xmax(ListaIntervale2D *lista){
    int ymax=-1;
    for (int i = 0; i < lista->dimensiune; ++i)
    {
        if(lista->intervale[i]->punct_dreapta->x > ymax)
            ymax = lista->intervale[i]->punct_dreapta->x; 
    }
    return ymax;
}
int determinant (Punct2D *p1,Punct2D *p2,Punct2D *p3){
    return ((p1->x * p2->y)+(p1->y * p3->x)+(p2->x * p3->y)-(p3->x * p2->y)-(p3->y * p1->x)-(p2->x * p1->y));

}
void interschimba_intervale(Interval2D *i1,Interval2D *i2){
    int x1,y1,x2,y2;
    x1=i1->punct_stanga->x;
    x2=i1->punct_dreapta->x;
    y1=i1->punct_stanga->y;
    y2=i1->punct_dreapta->y;
    i1->punct_stanga->x=i2->punct_stanga->x;
    i1->punct_dreapta->x=i2->punct_dreapta->x;
    i1->punct_stanga->y=i2->punct_stanga->y;
    i1->punct_dreapta->y=i2->punct_dreapta->y;
    i2->punct_stanga->x=x1;
    i2->punct_dreapta->x=x2;
    i2->punct_stanga->y=y1;
    i2->punct_dreapta->y=y2;
}

ListaIntervale2D *ListaOrdonata (ListaIntervale2D *lista){
    for (int i = 0; i < lista->dimensiune-1; ++i)
    {
        for (int j = i+1; j < lista->dimensiune; ++j)
        {
            if(lista->intervale[i]->punct_stanga->x > lista->intervale[j]->punct_stanga->x){
                interschimba_intervale(lista->intervale[i],lista->intervale[j]);
            }
        }
    }
    return lista;
}
int interval_orizontal(Interval2D *interval){
    if(interval->punct_stanga->y==interval->punct_dreapta->y)
        return 1;
    return 0;
}
int nu_exista_drepte_verticale_pe_axa(int x,ListaIntervale2D *lista){
    for (int i = 0; i < lista->dimensiune; ++i)
    {
        if(lista->intervale[i]->punct_stanga->x==lista->intervale[i]->punct_dreapta->x && 
            lista->intervale[i]->punct_stanga->x==x)
            return 0;
    }
    return 1;
}
int calculeaza_numar_intersectii(ListaIntervale2D *lista) {
    // TODO calculati numarul de intersectii folosind arbori de intervale conform enuntului
    // Hint: initializarea arborelui:
    ArboreDeIntervale *arbore = construieste_arbore(0,cauta_ymax(lista), 0, actualizare_cu_delta, suma_raspunsurilor);
    ListaIntervale2D *lista_ordonata=ListaOrdonata(lista);
    lista_ordonata->dimensiune=lista->dimensiune;
    int kk=0;
    int xmax=cauta_xmax(lista_ordonata);
    for (int i = 0; i <=xmax;++i)
    {
        int ok=nu_exista_drepte_verticale_pe_axa(i,lista_ordonata);
        for (int j = 0; j < lista_ordonata->dimensiune; ++j)
        {   
            if(i == lista_ordonata->intervale[j]->punct_stanga->x){
                if(interval_orizontal(lista_ordonata->intervale[j])){
                    Interval *interval=(Interval*)malloc(sizeof(Interval2D));
                    interval->capat_stanga=lista_ordonata->intervale[j]->punct_stanga->y;
                    interval->capat_dreapta=(interval->capat_stanga);
                    actualizare_interval_in_arbore(arbore,interval,1);
                }

            }
            if(i == lista_ordonata->intervale[j]->punct_dreapta->x&&ok==0){
                    if(!(interval_orizontal(lista_ordonata->intervale[j]))){
                        Interval *interval=(Interval*)malloc(sizeof(Interval2D));
                        interval->capat_stanga=lista_ordonata->intervale[j]->punct_stanga->y;
                        interval->capat_dreapta=lista_ordonata->intervale[j]->punct_dreapta->y;
                        kk+=interogare_interval_in_arbore(arbore,interval);
                        ok=1;
                        j=0;
                    }
                }
            if(i == lista_ordonata->intervale[j]->punct_dreapta->x){
                if(interval_orizontal(lista_ordonata->intervale[j])){
                    Interval *interval=(Interval*)malloc(sizeof(Interval2D));
                    interval->capat_stanga=lista_ordonata->intervale[j]->punct_dreapta->y;
                    interval->capat_dreapta=(interval->capat_stanga);
                    if(ok==1)
                        actualizare_interval_in_arbore(arbore,interval,-1);
                }
            }          
        }
    }
    return kk;
}


int calculeaza_numar_intersectii_trivial(ListaIntervale2D *lista) {
    int nr_intersectii=0;
    for (int i = 0; i < lista->dimensiune-1; ++i)
    {
        for (int j = i+1; j < lista->dimensiune; ++j)
        {   int ok=1;
            //printf("%d\n",determinant(lista->intervale[i]->punct_stanga,lista->intervale[j]->punct_stanga,lista->intervale[j]->punct_dreapta));
            if((determinant(lista->intervale[i]->punct_stanga,lista->intervale[j]->punct_stanga,lista->intervale[j]->punct_dreapta)*
                determinant(lista->intervale[i]->punct_dreapta,lista->intervale[j]->punct_stanga,lista->intervale[j]->punct_dreapta) <=0)&&
                (determinant(lista->intervale[j]->punct_stanga,lista->intervale[i]->punct_stanga,lista->intervale[i]->punct_dreapta)*
                determinant(lista->intervale[j]->punct_dreapta,lista->intervale[i]->punct_stanga,lista->intervale[i]->punct_dreapta))<=0){
                nr_intersectii++;
                ok=0;
            }
            if(ok==0){
                if((lista->intervale[i]->punct_dreapta->x < lista->intervale[j]->punct_stanga->x) && (lista->intervale[i]->punct_stanga->y == lista->intervale[j]->punct_dreapta->y)) // tratez cazul cand sunt pe aceeasi dreapta dar nu se intersecteaza ;) (determinantul nu acopera aceasta problema ;)
                    nr_intersectii--;
            } 
        }
    }
    return nr_intersectii;

}
