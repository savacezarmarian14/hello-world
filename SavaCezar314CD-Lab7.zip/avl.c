#include "avl.h"

Tree createTree(T value) {
	Tree root = malloc(sizeof(struct node));
	root->value = value;
	root->left = NULL;
	root->right = NULL;
	root->height = 1;
	return root;
}

int maximum(int a, int b) {
	return (a > b) ? a : b;
}

int height(Tree root) {
	if (root == NULL)
		return 0;
	return root->height;
}

int balancedFactor(Tree root) {
	if (root == NULL)
		return 0;
	return height(root->left) - height(root->right);
}

void updateHeight(Tree root) {
	root->height = maximum(height(root->left), height(root->right)) + 1;
}

Tree leftRotation(Tree x) {
	Tree y=x->right;
	Tree B=y->left;
	y->left=x;
	x->right=B;
	updateHeight(x);
	updateHeight(y);
	return y;
}

Tree rightRotation(Tree x) {
	Tree y=x->left;
	Tree B=y->right;
	y->right=x;
	x->left=B;
	updateHeight(x);
	updateHeight(y);
	return y;
}

Tree insert(Tree root, T value) {
	if(root==NULL)
		return createTree(value);
	if(root->value < value)
		root->right= insert(root->right,value);
	if(root->value > value)
		root->left= insert(root->left,value);
	updateHeight(root);
	int BF=balancedFactor(root);
	if(BF >= 2){
		if(value<root->left->value)
			root=rightRotation(root);
		else if(value>root->left->value){
			root->left=leftRotation(root->left);
			root=rightRotation(root);
		}
	}
	else if(BF <= -2){
		if(value>root->right->value)
			root=leftRotation(root);
		else if(value<root->right->value){
			root->right=rightRotation(root->right);
			root=leftRotation(root);
		}
	}

	return root;
}

Tree freeTree(Tree root) {
	if (root == NULL)
		return NULL;
	root->left = freeTree(root->left);
	root->right = freeTree(root->right);
	free(root);
	return NULL;
}

