#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* Key;
typedef int Value;
typedef long(*HashFunction)(Key, long);

typedef struct Element {
  Key key;
  Value value;
  struct Element *next;
} Element;

typedef struct HashTable {
  Element** elements;
  long size;
  HashFunction hashFunction;
} HashTable;

void initHashTable(HashTable **h, long size, HashFunction f) {
  // Cerinta 1
	HashTable *aux = malloc(sizeof(HashTable));
	aux->size = size;
	aux->hashFunction = f;
	aux->elements = calloc(size , sizeof(Element *));
	*h = aux;
}

int exists(HashTable *hashTable, Key key) {
  // Cerinta 1
	int INDEX=hashTable->hashFunction(key,hashTable->size);
	Element *iter=hashTable->elements[INDEX];
	while(iter!=NULL){
		if(strcmp(key,iter->key)==0 && iter->value>0){
			iter->value-=1;
			return 1;
		}
		iter=iter->next;
	}	
  return 0;
}
int exists2(HashTable *hashTable, Key key) {
  // Cerinta 1
	int INDEX=hashTable->hashFunction(key,hashTable->size);
	Element *iter=hashTable->elements[INDEX];
	while(iter!=NULL){
		if(strcmp(key,iter->key)==0){
			iter->value+=1;
			return 1;
		}
		iter=iter->next;
	}	
  return 0;
}

Value get(HashTable *hashTable, Key key) {
  // Cerinta 1
	int INDEX=hashTable->hashFunction(key,hashTable->size);
	Element *iter=hashTable->elements[INDEX];
	while(iter!=NULL){
		if(strcmp(iter->key,key)==0)
			return iter->value;
	}		
}

void put(HashTable *hashTable, Key key, Value value) {
  int INDEX=hashTable->hashFunction(key,hashTable->size);
  Element *iter=hashTable->elements[INDEX];
  Element *aux=(Element*)malloc(sizeof(Element));
  aux->value=value;
  aux->next=NULL;
  Key auxk=strdup(key);
  aux->key=auxk;
  if(exists2(hashTable,key))
  	return ;
  if(iter==NULL){

  	hashTable->elements[INDEX]=aux;
  	return;
  }
  while(iter->next!=NULL){
  	iter=iter->next;
  }
  iter->next=aux;
}

void deleteKey(HashTable *hashTable, Key key) {
  // Cerinta 1
	int INDEX=hashTable->hashFunction(key,hashTable->size);
	if(strcmp(key,hashTable->elements[INDEX]->key)==0)
		hashTable->elements[INDEX]=hashTable->elements[INDEX]->next;
	for(Element *iter=hashTable->elements[INDEX];iter->next!= NULL; iter=iter->next){
		if(strcmp(iter->next->key,key)==0){
			Element *deSters=iter->next;
			iter->next=iter->next->next;
			free(deSters);
		}
	}
}

void print(HashTable *hashTable) {
  for (int i = 0; i < hashTable->size; ++i)
  {
  	printf("%d:\n",i);
  	Element *iter=hashTable->elements[i];
  	while(iter!=NULL){
  		printf("\t%s:%d\n",iter->key,iter->value);
  		iter=iter->next;
  	}
  }
}

void freeHashTable(HashTable *hashTable) {
  free(hashTable);
}


long hash1(Key word, long size) {
  // Cerinta 2
	long h=0;
	for (int i = 0; i < strlen(word); ++i)
	{
		h=h*17+word[i];
	}
  return h%size;
}

int main(int argc, char* argv[]) {
  HashTable *hashTable;
  HashTable *h2;
  FILE *f1, *f2;
  char word[256];
  long hashSize, common=0;

  hashSize = atoi(argv[1]);
  f1 = fopen(argv[2], "r");
  f2 = fopen(argv[3], "r");

  initHashTable(&hashTable, hashSize, &hash1);
  initHashTable(&h2, hashSize, &hash1);
 
  // Cerinta 3
  Key key=malloc(100*sizeof(char));
  while (fscanf(f1,"%s",key)!=EOF)
  	{
  		put(hashTable,key,1);
  		printf("%s\n",key);
  	}
  print(hashTable);
  // Cerinta 4
  while(fscanf(f2,"%s",key)!=EOF){
  	if(exists(hashTable,key))
  		common++;
  }
  // ...

  printf("Common words: %ld\n", common);

  fclose(f1);
  fclose(f2);
  return 0;
}
